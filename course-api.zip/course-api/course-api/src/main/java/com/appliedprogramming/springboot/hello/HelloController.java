package com.appliedprogramming.springboot.hello;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

	@RequestMapping("/Hello")
	public String SayHi() {
		String objectToReturn = "{ id: '1', course: 'English' }";
		return objectToReturn;
	}
}
