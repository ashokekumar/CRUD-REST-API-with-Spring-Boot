package com.appliedprogramming.springboot.topic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

@Service
public class TopicService {

private List<Topic> topics = new ArrayList<Topic>(
		
		  Arrays.asList(
				new Topic("Spring","SpringFrame Work","Spring Framework"),
				new Topic("Java","Java Course","Java course description"),
				new Topic("Node","Node Js","Node Js description")
				));

public List<Topic> getAllTopics() {
		return topics;
	}



public Topic getTopic(String id) {

	Topic topic =null;

	for(Topic t:topics) {	
		if(t.getId().equals(id)) {
		topic =t; break;}
	}

	return topic;
}


public void addTopics(@RequestParam Topic topic)
{
	topics.add(topic);
}
//Add topic



public void updateTopic(String id, Topic topic) {
	
	for (int i=0; i<=topics.size(); i++) {
		if(topics.get(i).getId().equals(id)) {
			topics.set(i, topic);
			return;
		}
		
	}
}



public void deleteTopic(String id) {
	
	for (int i=0; i<=topics.size(); i++) {
		if(topics.get(i).getId().equals(id)) {
			topics.remove(i);
			return;
		}
		
	}
}

//Delete topic



}
